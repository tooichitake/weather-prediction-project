# Weather Prediction Package

A machine learning package for weather prediction in Sydney, Australia, focusing on rainfall and precipitation forecasting.

## Overview

This package provides tools for:
- **Binary Classification**: Predicting whether it will rain exactly 7 days in the future
- **Regression**: Predicting the cumulated volume of precipitation (in mm) within the next 3 days

## Features

- Data collection from Open Meteo Historical Weather API
- Comprehensive feature engineering (lag features, rolling statistics, date features)
- Multiple model support (LightGBM, Logistic/Linear Regression)
- Hyperparameter optimization with cross-validation
- Model persistence and versioning
- Visualization tools for data analysis

## Installation

### Using Poetry (Recommended)

```bash
# Install Poetry if not already installed
pip install poetry

# Install the package and dependencies
poetry install

# Install with development dependencies
poetry install --with dev

# Install with API dependencies
poetry install --with api
```

### Using pip

```bash
# Install from TestPyPI
pip install -i https://test.pypi.org/simple/ weather

# Install from source
pip install -e .
```

## Quick Start

```python
from weather.dataset import WeatherDataCollector
from weather.features import create_features, create_target_rain, create_target_precipitation
from weather.modeling.train import train_model

# Download weather data
collector = WeatherDataCollector()
df = collector.fetch_weather_data(start_date="2020-01-01", end_date="2024-12-31")

# Create features and targets
df = create_features(df)
df = create_target_rain(df, days_ahead=7)
df = create_target_precipitation(df, days_ahead=3)

# Train a model
model, metrics = train_model(
    df,
    target_column="will_rain_in_7_days",
    model_type="lightgbm"
)
```

## Project Structure

```
weather/
   __init__.py          # Package initialization
   dataset.py           # Data collection from Open Meteo API
   features.py          # Feature engineering functions
   modeling/
      __init__.py
      train.py        # Model training utilities
      predict.py      # Prediction utilities
   plots.py            # Visualization functions
   config.py           # Configuration settings
```

## Development

### Running Tests

```bash
# Using Make
make test

# Using Poetry
poetry run pytest

# With coverage
poetry run pytest --cov=weather
```

### Code Quality

```bash
# Format code
make format

# Run linting
make lint

# Run all checks
make check
```

### Building the Package

```bash
# Build distributions
make build

# Upload to TestPyPI
make upload-test
```

## API Deployment

The package is designed to be used with a FastAPI application for serving predictions. The API should include:

- `/` - Project description
- `/health/` - Health check endpoint
- `/predict/rain/` - Rain prediction (7 days ahead)
- `/predict/precipitation/fall` - Precipitation volume prediction (3 days ahead)

## Data Source

Weather data is sourced from the [Open Meteo Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api) for Sydney, Australia (latitude: -33.8678, longitude: 151.2073).

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Authors

- Your Name - Initial work

## Acknowledgments

- Open Meteo for providing the weather data API
- University of Technology Sydney for project requirements